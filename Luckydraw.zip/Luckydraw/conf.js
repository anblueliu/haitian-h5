
document.write("<link href=\"/css/common.css?v=12334\" rel=\"stylesheet\" />");
document.write("<script src=\"/js/jquery.min.js\"></script>");
document.write("<script src=\"/js/jquery.cxselect.min.js\"></script>");
document.write("<script src=\"/js/base.js\"></script>");

